# -*- coding: utf-8 -*-
"""
Step 1.5：款目編號重編與交叉引用檢查

什麼時候要用：
你在內規裡刪掉或插入了某一款、某一目之後，跑這支程式。

刪掉「二、」之後會發生三件事，一件比一件嚴重：

1. 編號斷掉        剩下 一、三、四、  ── 肉眼容易漏看，尤其 50 頁的內規
2. 對照表被灌爆    手動把 三、改成二、、四、改成三、之後，對照表會多出一堆
                   「修改」，但那些條文一個字都沒動，只是編號位移
3. 交叉引用失效    別的條文寫「依前條第二款規定」，原本的第二款已經不存在，
                   這句話現在指到完全不同的內容 ── 這是真正會出事的地方

這支程式處理前兩件，第三件明確列出來給人工判斷。

--------------------------------------------------------------------------
為什麼「條」預設不重編
--------------------------------------------------------------------------
法制作業慣例上，刪除某一條時，後面的條號不跟著往前遞補；被刪的條保留條號並
註記「第○條　（刪除）」。這樣做的理由很實際：全文與其他規章裡引用「第五十條」
的地方，不會因為前面刪了一條就全部指錯。新增條文也是同樣道理，才會有
「第五條之一」這種寫法。

所以本程式預設只重編「款」與「目」（它們是條的內部結構，重編不影響外部引用），
條號一律不動，只在發現斷號時提醒你要不要補「（刪除）」註記。
若貴單位的內規慣例是條號也要遞補，加 --renumber-articles 明確指定。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python renumber.py 新版內規.docx
        檢查模式：只報告問題，不動檔案

    python renumber.py 新版內規.docx --apply
        重編款目編號，輸出「重編後_新版內規.docx」

    python renumber.py 新版內規.docx --apply --rewrite-refs
        連同交叉引用一起改寫（只改「被引用的款目還在、只是換號」那種；
        引用到已刪除款目的一律不動，強制人工處理）

    python renumber.py 新版內規.docx --old 舊版內規.docx
        額外比對舊版，找出被整條刪掉的條號，提醒補「（刪除）」註記
"""

import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     resolve_output, strip_article_no, HAS_DOCX)

CN = "一二三四五六七八九十"
_CN_VALUES = {ch: idx + 1 for idx, ch in enumerate(CN)}

_CLAUSE_RE = re.compile(r"^([%s]+)(\s*、)" % CN)
_ITEM_RE = re.compile(r"^([（(])\s*([%s\d]+)\s*([）)])" % CN)


def cn_to_int(text):
    """中文數字轉阿拉伯數字，支援到 99，款目編號夠用。抓不到回 None。"""
    text = text.strip()
    if text.isdigit():
        return int(text)
    if not text or any(ch not in CN for ch in text):
        return None
    if "十" not in text:
        return _CN_VALUES.get(text)
    if text == "十":
        return 10
    if text.startswith("十"):
        return 10 + _CN_VALUES.get(text[1:], 0)
    tens, _, ones = text.partition("十")
    return _CN_VALUES.get(tens, 0) * 10 + (_CN_VALUES.get(ones, 0) if ones else 0)


def int_to_cn(value):
    """阿拉伯數字轉中文數字，支援到 99。"""
    if value <= 10:
        return CN[value - 1]
    if value < 20:
        return "十" + (CN[value - 11] if value > 10 else "")
    tens, ones = divmod(value, 10)
    return CN[tens - 1] + "十" + (CN[ones - 1] if ones else "")


# ---------------------------------------------------------------------------
# 掃描目前的編號狀態
# ---------------------------------------------------------------------------

def scan(paragraphs):
    """
    走一遍全文，回傳每一段的編號資訊。

    每個元素：
        {"index": 段次(從1), "level": 條/款/目/其他, "article": 所屬條號,
         "written": 目前寫的號碼(整數), "clause_written": 所屬款的號碼}
    """
    contexts = build_hierarchy(paragraphs)
    entries = []
    clause_written = None

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        level = context["level"]
        written = None

        if level == "條":
            clause_written = None
        elif level == "款":
            match = _CLAUSE_RE.match(text)
            written = cn_to_int(match.group(1)) if match else None
            clause_written = written
        elif level == "目":
            match = _ITEM_RE.match(text)
            written = cn_to_int(match.group(2)) if match else None

        entries.append({
            "index": idx, "level": level, "article": context["article"],
            "written": written, "clause_written": clause_written,
        })
    return entries


def plan_renumber(paragraphs, entries):
    """
    算出「哪一段的編號要從幾號改成幾號」。

    款：同一條底下的款，由上而下重編為 一、二、三……
    目：同一條同一款底下的目，重編為 (一)(二)(三)……

    回傳 (變更清單, 款對照表, 目對照表)。
    對照表是給交叉引用檢查用的：{(條號, 舊號): 新號}
    """
    changes = []
    clause_map = {}
    item_map = {}

    clause_counter = {}
    item_counter = {}

    for entry in entries:
        article = entry["article"]

        if entry["level"] == "款":
            clause_counter[article] = clause_counter.get(article, 0) + 1
            new_no = clause_counter[article]
            if entry["written"] is not None:
                clause_map[(article, entry["written"])] = new_no
            if entry["written"] != new_no:
                changes.append({
                    "index": entry["index"], "level": "款",
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _CLAUSE_RE.sub(
                        lambda m: int_to_cn(new_no) + m.group(2),
                        paragraphs[entry["index"] - 1], count=1),
                })

        elif entry["level"] == "目":
            key = (article, entry["clause_written"])
            item_counter[key] = item_counter.get(key, 0) + 1
            new_no = item_counter[key]
            if entry["written"] is not None:
                item_map[(article, entry["clause_written"], entry["written"])] = new_no
            if entry["written"] != new_no:
                changes.append({
                    "index": entry["index"], "level": "目",
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _ITEM_RE.sub(
                        lambda m: m.group(1) + int_to_cn(new_no) + m.group(3),
                        paragraphs[entry["index"] - 1], count=1),
                })

    return changes, clause_map, item_map


def find_numbering_gaps(entries):
    """
    找出編號本身就有問題的地方（斷號、重號、沒從一開始）。

    這是「使用者刪了款但沒重編」的直接證據，也是最容易在 50 頁內規裡漏看的東西。
    """
    problems = []
    groups = {}
    for entry in entries:
        if entry["level"] == "款":
            groups.setdefault(("款", entry["article"]), []).append(entry)
        elif entry["level"] == "目":
            groups.setdefault(("目", entry["article"], entry["clause_written"]),
                              []).append(entry)

    for key, group in groups.items():
        written = [e["written"] for e in group]
        if any(w is None for w in written):
            continue
        expected = list(range(1, len(written) + 1))
        if written == expected:
            continue

        if len(set(written)) != len(written):
            reason = "編號重複"
        elif written[0] != 1:
            reason = "沒有從第一%s開始" % key[0]
        else:
            reason = "編號不連續（中間有缺號，通常是刪除後沒有重編）"

        problems.append({
            "level": key[0], "article": key[1],
            "written": written, "expected": expected, "reason": reason,
            "first_index": group[0]["index"],
        })
    return problems


def find_deleted_articles(old_paragraphs, new_paragraphs):
    """
    比對新舊版，找出被整條刪掉的條號。

    條號預設不重編，所以刪掉之後新版會出現條號斷點。依法制慣例，
    這裡應該保留條號並註記「第○條　（刪除）」，讓後面的條號維持不變。
    """
    def article_numbers(paragraphs):
        found = []
        for context in build_hierarchy(paragraphs):
            if context["level"] == "條" and context["article"] not in found:
                found.append(context["article"])
        return found

    old_articles = article_numbers(old_paragraphs)
    new_articles = set(article_numbers(new_paragraphs))
    return [a for a in old_articles if a not in new_articles]


# ---------------------------------------------------------------------------
# 交叉引用
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 交叉引用解析
# ---------------------------------------------------------------------------
#
# 這一段是整支程式風險最高的地方。內規裡的引用寫法遠比「第五條第二款」複雜：
#
#     前條第三款及第四款      ← 「及第四款」的範圍要延續前面的「前條」
#     第五條第二款至第四款    ← 範圍寫法，實際指的是第二、三、四款
#     依前款規定              ← 相對引用，要看它自己在第幾款
#     前二項                  ← 往前數兩個
#     依第五條規定            ← 只到條層級
#
# 每一種漏掉，就是一處指錯的引用送進正式修法文件。所以這裡用逐字掃描配上
# 範圍狀態，而不是一條大正規表示式硬套。
#
# 判定結果分四種：
#     安全      引用的目標編號沒變
#     需改寫    目標還在、只是換號，機械式改寫是安全的
#     危險      目標已被刪除，沒有正確的改寫方式
#     無法判定  解析不出來（可能是原文寫法特殊，也可能本來就寫錯）
#
# 「無法判定」一定要列出來，不能默默跳過 —— 沉默才是最危險的結果。

_TOKEN_RE = re.compile(
    r"(?P<article>第\s*[%(cn)s\d]+\s*條(?:\s*之\s*[%(cn)s\d]+)?)"
    r"|(?P<prev_article>前\s*[%(cn)s]*\s*條)"
    r"|(?P<this_article>本條)"
    r"|(?P<para>第\s*[%(cn)s\d]+\s*項)"
    r"|(?P<prev_para>前\s*[%(cn)s]*\s*項)"
    r"|(?P<clause>第\s*[%(cn)s\d]+\s*款)"
    r"|(?P<prev_clause>前\s*[%(cn)s]*\s*款)"
    r"|(?P<all_clause>各\s*款)"
    r"|(?P<item>第\s*[%(cn)s\d]+\s*目)"
    r"|(?P<prev_item>前\s*[%(cn)s]*\s*目)"
    r"|(?P<rangemark>至)"
    r"|(?P<conj>[及或與和、])"
    r"|(?P<stop>[。；：])" % {"cn": CN})

_NUM_IN_TOKEN = re.compile(r"[%s\d]+" % CN)


def _token_number(token_text):
    """從「第十二款」這種字串裡取出數字。取不到回 None。"""
    match = _NUM_IN_TOKEN.search(token_text.replace("第", "").replace("前", ""))
    return cn_to_int(match.group(0)) if match else None


def _relative_offset(token_text):
    """「前款」= 往前 1 個，「前二款」= 往前 2 個。"""
    number = _token_number(token_text)
    return number if number else 1


def parse_references(text, own_article, own_clause, previous_article,
                    own_para=None):
    """
    解析一段文字裡的所有條款目引用。

    own_article／own_clause／own_para：這一段自己所在的條、款、項，
    用來解析沒寫範圍的引用（例如條文裡直接寫「第三款」，指的就是本條第三款；
    「前項」指的是本條的前一項）。
    previous_article：這一段的「前條」是哪一條。

    回傳引用清單，每筆含 span（在原文的起訖位置，供改寫用）、
    article（指向哪一條）、kind（款／目／項／條）、numbers（指向哪幾號）。
    """
    references = []
    scope_article = own_article
    scope_span = None        # 範圍前綴在原文的位置，例如「前條」「第五條」
    pending_range = False
    last_reference = None

    def display_quote(token_span):
        """
        報告裡要顯示的引用字句。

        span 只涵蓋號碼那一段（改寫時只能動那裡），但報告寫「引用『第二款』」
        會讓人看不出是哪一條的第二款。所以緊接在範圍前綴後面的引用，
        顯示時把前綴一起帶上，變成「前條第二款」。
        """
        if scope_span and scope_span[1] == token_span[0]:
            return text[scope_span[0]:token_span[1]]
        return text[token_span[0]:token_span[1]]

    for match in _TOKEN_RE.finditer(text):
        kind = match.lastgroup
        token = match.group(0)

        if kind == "stop":
            # 句子結束，範圍重設回本條，「及」的延續也中斷
            scope_article = own_article
            scope_span = None
            pending_range = False
            last_reference = None
            continue

        if kind == "conj":
            # 「及」「或」「、」本身不重設範圍，讓後面的「第四款」延用前面的條
            continue

        if kind == "rangemark":
            pending_range = True
            continue

        if kind == "article":
            scope_article = re.sub(r"\s+", "", token)
            scope_span = match.span()
            # 條層級的引用本身也要記一筆。「本公司得依第五條規定辦理」這種
            # 沒帶款目的引用，只要第五條被整條刪掉就會指空，不能漏掉。
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "條", "numbers": None, "is_range": False,
            })
            last_reference = None
            continue

        if kind == "prev_article":
            offset = _relative_offset(token)
            scope_article = previous_article if offset == 1 else ""
            scope_span = match.span()
            last_reference = None
            continue

        if kind == "this_article":
            scope_article = own_article
            scope_span = match.span()
            last_reference = None
            continue

        if kind in ("para", "prev_para"):
            # 項不像款目那樣把編號寫在文字裡，所以沒有「重編」可言；
            # 但它一樣會出事——刪掉一個項，後面的項次全部往前移，
            # 「前項」「第二項」就指到別的東西了。
            #
            # 早期版本這裡直接 continue，等於靜默略過，違反本程式的原則
            # （解析不出來也要列出來，沉默才是最危險的結果）。現在照樣產生
            # 引用記錄，交給 _judge 與 scan_reference_drift 判斷。
            if kind == "prev_para":
                offset = _relative_offset(token)
                target = (own_para - offset) if own_para else None
                if target and target >= 1:
                    note, hint = "", None
                elif own_para:
                    # 知道自己是第幾項，卻算出往前指到第 0 項或更前面，
                    # 那就是明確的錯：本條第一項前面沒有項可以指。
                    if own_para == 1:
                        note = ("這一段是本條的第一項，前面沒有項可以指，"
                                "「%s」指不到東西" % token)
                    else:
                        note = ("這一段是本條的第 %d 項，前面只有 %d 項，"
                                "「%s」要再往前數 %d 項，指不到東西"
                                % (own_para, own_para - 1, token, offset))
                    hint = "危險"
                else:
                    note = ("這一段本身不在任何條的項次之內，"
                            "解析不出「%s」指的是哪一項" % token)
                    hint = None
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": [target] if target and target >= 1 else None,
                    "note": note, "status_hint": hint,
                })
            else:
                number = _token_number(token)
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": [number] if number else None,
                    "note": "" if number else "解析不出項次",
                })
            last_reference = None
            continue

        if kind == "all_clause":
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "款", "numbers": None, "note": "「各款」指全部，重編不影響",
            })
            last_reference = None
            continue

        if kind in ("clause", "item"):
            unit = "款" if kind == "clause" else "目"
            number = _token_number(token)
            if number is None:
                continue

            if pending_range and last_reference and last_reference["kind"] == unit:
                # 「第二款至第四款」：把範圍展開成 2、3、4，並把兩端合併成一筆
                start = last_reference["numbers"][0]
                last_reference["numbers"] = list(range(min(start, number),
                                                       max(start, number) + 1))
                last_reference["span"] = (last_reference["span"][0], match.span()[1])
                last_reference["raw"] = text[last_reference["span"][0]:
                                             last_reference["span"][1]]
                last_reference["is_range"] = True
                last_reference["is_range"] = True
                pending_range = False
                continue

            reference = {
                # span 只涵蓋號碼那一段，改寫時只能動這裡；
                # raw 是報告要顯示的字句，會把「前條」「第五條」這種前綴帶上；
                # token 是純號碼字串，改寫時拿它去換，不能用 raw，
                # 否則「第五條第四款」會被改成「第五條第五條第三款」。
                "span": match.span(), "raw": display_quote(match.span()),
                "token": token, "article": scope_article,
                "kind": unit, "numbers": [number], "is_range": False,
            }
            references.append(reference)
            last_reference = reference
            pending_range = False
            continue

        if kind in ("prev_clause", "prev_item"):
            unit = "款" if kind == "prev_clause" else "目"
            offset = _relative_offset(token)
            if own_clause is None:
                references.append({
                    "span": match.span(), "raw": token, "article": scope_article,
                    "kind": unit, "numbers": None,
                    "note": "這一段本身不在任何%s之下，解析不出「%s」指的是哪一%s"
                            % (unit, token, unit),
                })
            else:
                target = own_clause - offset
                references.append({
                    "span": match.span(), "raw": token, "article": scope_article,
                    "kind": unit,
                    "numbers": [target] if target >= 1 else None,
                    "note": "" if target >= 1 else "「%s」往前數超出範圍" % token,
                })
            last_reference = None
            continue

    return references


def scan_references(paragraphs, entries, clause_map, item_map,
                    known_articles=None, articles_with_clauses=None):
    """
    掃描全文的交叉引用，判斷它們會不會因為重編而指錯。

    clause_map／item_map 是 plan_renumber() 算出來的「舊號 → 新號」對照。
    known_articles 是全文實際存在的條號集合，用來抓出指向不存在條號的引用。
    """
    contexts = build_hierarchy(paragraphs)
    entry_by_index = {e["index"]: e for e in entries}
    if articles_with_clauses is None:
        articles_with_clauses = {e["article"] for e in entries
                                 if e["level"] == "款" and e["article"]}

    # 每一條有幾項，用來判斷「第三項」這種引用指不指得到
    para_counts = {}
    for context in contexts:
        if context["level"] in ("條", "項") and context["article"]:
            ordinal = _paragraph_ordinal(context) or 1
            key = context["article"]
            para_counts[key] = max(para_counts.get(key, 0), ordinal)

    findings = []

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        entry = entry_by_index.get(idx, {})
        own_clause = entry.get("clause_written")
        references = parse_references(
            text, context["article"], own_clause,
            _previous_article_of(contexts, idx),
            own_para=_paragraph_ordinal(context))

        for reference in references:
            finding = _judge(reference, text, idx, clause_map, item_map,
                             own_clause, known_articles, articles_with_clauses,
                             para_counts)
            if finding:
                findings.append(finding)

    return findings


def _judge(reference, text, index, clause_map, item_map, own_clause,
           known_articles, articles_with_clauses=None, para_counts=None):
    """判斷單一筆引用會不會出問題。沒問題（安全）就回 None。"""
    base = {"index": index, "text": text, "quote": reference["raw"],
            "article": reference["article"], "kind": reference["kind"]}

    if reference.get("note") and reference.get("numbers") is None:
        if "各款" in reference["raw"]:
            return None      # 「各款」指全部，不受重編影響
        base.update({"status": reference.get("status_hint") or "無法判定",
                     "note": reference["note"]})
        return base

    if not reference["article"]:
        base.update({"status": "無法判定",
                     "note": "解析不出這個引用指向哪一條，請人工確認"})
        return base

    if known_articles is not None and reference["article"] not in known_articles:
        base.update({"status": "危險",
                     "note": "引用的 %s 在新版中不存在" % reference["article"]})
        return base

    if reference["kind"] == "條":
        return None          # 條號沒有重編，條存在就沒事

    if reference["kind"] == "項":
        # 項沒有寫在文字裡的編號，沒辦法機械式改寫；能做的是確認它指得到，
        # 指不到就一定要講。實際「指到的內容變了沒有」由 scan_reference_drift
        # 比對新舊版來抓。
        counts = para_counts or {}
        total = counts.get(reference["article"], 0)
        wanted = reference["numbers"][0]
        if not total:
            base.update({"status": "無法判定",
                         "note": "%s 底下推算不出項次，請人工確認這個引用指向哪裡"
                                 % reference["article"]})
            return base
        if wanted > total:
            base.update({"status": "危險",
                         "note": "%s 只有 %d 項，但這裡引用第 %d 項，指不到"
                                 % (reference["article"], total, wanted)})
            return base
        return None

    # 引用的條底下根本沒有款，代表這個引用本身有問題（常見於「前條」指錯條），
    # 不能報成「已被刪除」——那會讓人以為是這次修訂造成的。
    if (reference["kind"] == "款" and articles_with_clauses is not None
            and reference["article"] not in articles_with_clauses):
        base.update({
            "status": "無法判定",
            "note": "%s 底下沒有任何款，這個引用可能原本就寫錯，請人工確認指向哪裡"
                    % reference["article"],
        })
        return base

    mapped = []
    for number in reference["numbers"]:
        if reference["kind"] == "款":
            mapped.append(clause_map.get((reference["article"], number)))
        else:
            mapped.append(item_map.get((reference["article"], own_clause, number)))

    if any(m is None for m in mapped):
        missing = [n for n, m in zip(reference["numbers"], mapped) if m is None]
        base.update({
            "status": "危險",
            "note": "引用的第%s%s已被刪除，沒有對應的新編號，必須人工確認要改成什麼"
                    % ("、".join(int_to_cn(n) for n in missing), reference["kind"]),
        })
        return base

    if mapped == reference["numbers"]:
        return None          # 安全，編號沒變

    # 範圍引用只有在重編後仍然連續時，機械式改寫才成立
    if reference.get("is_range") and mapped != list(range(mapped[0], mapped[-1] + 1)):
        base.update({"status": "危險",
                     "note": "範圍引用在重編後不再連續，必須人工改寫"})
        return base

    new_quote = _rewrite_quote(reference, mapped)
    base.update({
        "status": "需改寫", "new_quote": new_quote, "span": reference["span"],
        "note": "被引用的%s還在，只是從第%s%s變成第%s%s"
                % (reference["kind"],
                   "、".join(int_to_cn(n) for n in reference["numbers"]),
                   reference["kind"],
                   "、".join(int_to_cn(n) for n in mapped), reference["kind"]),
    })
    return base


def _rewrite_quote(reference, mapped):
    """把引用字句裡的號碼換成新號碼。範圍引用只換頭尾兩端。"""
    unit = reference["kind"]
    if reference.get("is_range"):
        return "第%s%s至第%s%s" % (int_to_cn(mapped[0]), unit,
                                   int_to_cn(mapped[-1]), unit)
    return re.sub(r"第\s*[%s\d]+\s*%s" % (CN, unit),
                  "第%s%s" % (int_to_cn(mapped[0]), unit),
                  reference.get("token", reference["raw"]), count=1)


def _paragraph_ordinal(context):
    """
    這一段是所在條的第幾項。build_hierarchy 已經算好了，從 ref 裡取出來。
    條文本體是第一項，之後每一個沒有編號的獨立段落依序遞增。
    """
    ref = context.get("ref", "")
    match = re.search(r"第([%s]+)項$" % CN, ref)
    if match:
        return cn_to_int(match.group(1))
    return 1 if context.get("level") in ("條", "項") else None


def _previous_article_of(contexts, index):
    """往回找「前條」指的是哪一條。"""
    current = contexts[index - 1]["article"]
    seen_current = False
    for context in reversed(contexts[:index]):
        if context["level"] != "條":
            continue
        if not seen_current:
            if context["article"] == current:
                seen_current = True
            continue
        return context["article"]
    return ""


def _paragraph_bodies(paragraphs):
    """
    把全文的「項」整理成 {(條號, 項次): 條文本體}。

    項沒有寫在文字裡的編號，項次是從條文本體開始往下數出來的。
    刪掉一個項，後面的項次全部往前移——「第二項」就指到別的東西了，
    這跟刪掉一個款完全是同一種問題，只是更難察覺，因為文件上看不出編號變動。
    """
    bodies = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs)):
        if context["level"] not in ("條", "項") or not context["article"]:
            continue
        ordinal = _paragraph_ordinal(context) or 1
        bodies[(context["article"], ordinal)] = strip_article_no(text).strip()
    return bodies


def _numbered_bodies(paragraphs, level):
    """
    把全文的款（或目）整理成 {(條號, 編號): 條文本體}，本體是去掉編號後的文字。

    用來比對「同一個編號，新舊版指的是不是同一件事」。
    """
    bodies = {}
    contexts = build_hierarchy(paragraphs)
    clause_written = None

    for text, context in zip(paragraphs, contexts):
        if context["level"] == "條":
            clause_written = None
        elif context["level"] == "款":
            match = _CLAUSE_RE.match(text)
            number = cn_to_int(match.group(1)) if match else None
            clause_written = number
            if level == "款" and number is not None:
                bodies[(context["article"], number)] = _CLAUSE_RE.sub("", text, count=1).strip()
        elif context["level"] == "目":
            match = _ITEM_RE.match(text)
            number = cn_to_int(match.group(2)) if match else None
            if level == "目" and number is not None:
                bodies[(context["article"], clause_written, number)] =                     _ITEM_RE.sub("", text, count=1).strip()
    return bodies


def scan_reference_drift(old_paragraphs, new_paragraphs):
    """
    比對新舊版，找出「編號沒變、但指的東西變了」的交叉引用。

    為什麼一定要有這一關：
    如果使用者刪掉第二款之後，自己先把三、四、改成二、三、才拿來跑，
    編號連續性檢查會說「完全乾淨」——因為它確實乾淨。但別的條文寫的
    「依前條第二款規定」，指的已經從被刪掉的「原保險單正本」變成
    「契約變更申請書」，意思整個換掉，而且**表面上完全看不出來**。
    這是所有情況裡最危險的一種，正是因為它看起來沒問題。

    做法很直接：同一個條號、同一個款號，比對新舊版的條文本體。
    不一樣就把兩邊都列出來，交給人判斷。不自動改。
    """
    old_clauses = _numbered_bodies(old_paragraphs, "款")
    new_clauses = _numbered_bodies(new_paragraphs, "款")
    old_paras = _paragraph_bodies(old_paragraphs)
    new_paras = _paragraph_bodies(new_paragraphs)
    contexts = build_hierarchy(new_paragraphs)

    pattern = re.compile(r"(前條|第\s*[%s\d]+\s*條(?:之\s*[%s\d]+)?)?"
                         r"第\s*([%s\d]+)\s*(款|項)" % (CN, CN, CN))

    findings = []
    for idx, (text, context) in enumerate(zip(new_paragraphs, contexts), 1):
        for match in pattern.finditer(text):
            scope_text, number_text, unit = match.groups()
            number = cn_to_int(number_text)
            if number is None:
                continue

            if scope_text and scope_text.startswith("前條"):
                target_article = _previous_article_of(contexts, idx)
            elif scope_text:
                target_article = re.sub(r"\s+", "", scope_text)
            else:
                target_article = context["article"]
            if not target_article:
                continue

            if unit == "款":
                old_body = old_clauses.get((target_article, number))
                new_body = new_clauses.get((target_article, number))
            else:
                old_body = old_paras.get((target_article, number))
                new_body = new_paras.get((target_article, number))

            if old_body is None or old_body == new_body:
                continue

            findings.append({
                "index": idx, "text": text, "quote": match.group(0),
                "target": "%s第%s%s" % (target_article, number_text, unit),
                "old_body": old_body,
                "new_body": new_body,
            })
    return findings


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

def report(problems, changes, deleted_articles, references, drift=None):
    """把檢查結果印出來。"""
    print("\n" + "=" * 62)
    print("編號檢查結果")
    print("=" * 62)

    if problems:
        print("\n【編號有問題的地方】共 %d 處" % len(problems))
        for problem in problems:
            print("  %s %s：%s" % (problem["article"], problem["level"], problem["reason"]))
            print("      目前：%s" % "、".join(int_to_cn(n) for n in problem["written"]))
            print("      應為：%s（第 %d 段起）"
                  % ("、".join(int_to_cn(n) for n in problem["expected"]),
                     problem["first_index"]))
    else:
        print("\n【編號有問題的地方】無，款目編號都是連續的")

    if changes:
        print("\n【要重編的段落】共 %d 段" % len(changes))
        for change in changes[:20]:
            print("  第%d段 %s %s：第%s%s → 第%s%s"
                  % (change["index"], change["article"], change["level"],
                     int_to_cn(change["old"]) if change["old"] else "?", change["level"],
                     int_to_cn(change["new"]), change["level"]))
        if len(changes) > 20:
            print("  …另有 %d 段（完整清單見輸出檔）" % (len(changes) - 20))
    else:
        print("\n【要重編的段落】無")

    if deleted_articles:
        print("\n【新版少掉的條號】共 %d 條" % len(deleted_articles))
        print("  依法制慣例，刪除的條應保留條號並註記「（刪除）」，讓後面的條號維持不變，")
        print("  否則全文及其他規章裡引用這些條號的地方會全部指錯。建議補上：")
        for article in deleted_articles:
            print("      %s　（刪除）" % article)

    dangerous = [r for r in references if r["status"] == "危險"]
    rewritable = [r for r in references if r["status"] == "需改寫"]
    unresolved = [r for r in references if r["status"] == "無法判定"]

    print("\n【交叉引用】")
    if not dangerous and not rewritable and not unresolved:
        print("  沒有受影響的交叉引用")
    if rewritable:
        print("  可機械式改寫 %d 處（加 --rewrite-refs 一併處理）：" % len(rewritable))
        for ref in rewritable:
            print("    第%d段「%s」→「%s」" % (ref["index"], ref["quote"], ref["new_quote"]))
            print("        %s" % ref["note"])
    if dangerous:
        print("\n  ⚠ 必須人工處理 %d 處 —— 本程式不會自動改：" % len(dangerous))
        for ref in dangerous:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))
    if unresolved:
        # 解析不出來的一定要列出來。沉默才是最危險的結果——使用者會以為
        # 程式看過了、沒問題，實際上是程式根本沒看懂那句話。
        print("\n  ? 解析不出來 %d 處 —— 可能是寫法特殊，也可能原文本來就寫錯，"
              "請人工看一下：" % len(unresolved))
        for ref in unresolved:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))

    if drift:
        print("\n【編號沒變、但指到的內容變了】共 %d 處 —— 這是最容易漏掉的一種"
              % len(drift))
        print("  表面上編號連續、看不出問題，但同一個編號在新舊版指的是不同的東西。")
        for item in drift:
            print("\n    第%d段：%s" % (item["index"], item["text"][:52]))
            print("        引用「%s」" % item["quote"])
            print("        舊版的%s是：%s" % (item["target"], item["old_body"]))
            if item["new_body"] is None:
                print("        新版沒有這一款了")
            else:
                print("        新版的%s是：%s" % (item["target"], item["new_body"]))
        print("\n  本程式不會自動改這些，請逐筆確認引用要指向哪裡。")

    print("=" * 62)


def apply_changes(paragraphs, changes, references, rewrite_refs):
    """套用重編（以及選用的引用改寫），回傳新的段落列表。"""
    result = list(paragraphs)
    for change in changes:
        result[change["index"] - 1] = change["new_text"]

    if rewrite_refs:
        # 只改「需改寫」那一類。「危險」與「無法判定」一律不動。
        # 用 span 由後往前取代：同一段裡可能出現兩個「第四款」，
        # 用字串比對會改到錯的那一個。
        by_paragraph = {}
        for ref in references:
            if ref["status"] == "需改寫" and ref.get("span"):
                by_paragraph.setdefault(ref["index"], []).append(ref)

        for index, refs in by_paragraph.items():
            text = result[index - 1]
            for ref in sorted(refs, key=lambda r: r["span"][0], reverse=True):
                start, end = ref["span"]
                text = text[:start] + ref["new_quote"] + text[end:]
            result[index - 1] = text

    return result


def write_output(paragraphs, source_path, outdir, prefix):
    """輸出重編後的檔案，格式跟來源檔一致。"""
    base = "重編後_" + os.path.basename(source_path)
    output_path = resolve_output(outdir, prefix, base)

    if output_path.lower().endswith(".docx"):
        if not HAS_DOCX:
            output_path = os.path.splitext(output_path)[0] + ".txt"
            print("提醒：沒有安裝 python-docx，改輸出純文字檔。")
        else:
            from docx import Document
            doc = Document()
            for text in paragraphs:
                doc.add_paragraph(text)
            doc.save(output_path)
            print("\n已輸出重編後檔案：%s" % output_path)
            return output_path

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(paragraphs) + "\n")
    print("\n已輸出重編後檔案：%s" % output_path)
    return output_path


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 1.5：款目編號重編與交叉引用檢查")
    parser.add_argument("regulation_file", help="要檢查的內規檔案（通常是你剛改好的新版）")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；給了才能找出被整條刪掉的條號")
    parser.add_argument("--apply", action="store_true",
                        help="實際重編款目編號並輸出檔案；不加就只檢查不動檔案")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連同可機械式改寫的交叉引用一起改（引用到已刪除款目的一律不動）")
    parser.add_argument("--renumber-articles", action="store_true",
                        help="連條號也重編。預設不做，因為法制慣例是保留條號並註記「（刪除）」")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    if args.renumber_articles:
        print("提醒：--renumber-articles 會讓刪除點之後的所有條號往前移。")
        print("      全文及其他規章裡引用這些條號的地方都會指錯，本程式無法替你追蹤，")
        print("      請確認貴單位的內規慣例確實是條號遞補，再繼續。\n")

    print("正在讀取：%s" % args.regulation_file)
    paragraphs = read_paragraphs(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))

    entries = scan(paragraphs)
    problems = find_numbering_gaps(entries)
    changes, clause_map, item_map = plan_renumber(paragraphs, entries)
    known_articles = {c["article"] for c in build_hierarchy(paragraphs)
                      if c["level"] == "條" and c["article"]}
    references = scan_references(paragraphs, entries, clause_map, item_map,
                                 known_articles=known_articles)

    deleted_articles = []
    drift = []
    if args.old:
        print("正在比對舊版：%s" % args.old)
        old_paragraphs = read_paragraphs(args.old)
        deleted_articles = find_deleted_articles(old_paragraphs, paragraphs)
        drift = scan_reference_drift(old_paragraphs, paragraphs)
    else:
        print("提醒：沒有給 --old，無法檢查「編號沒變但指到的內容變了」這種情況。")
        print("      強烈建議加上舊版一起跑：--old 舊版內規.docx")

    report(problems, changes, deleted_articles, references, drift)

    if not args.apply:
        if changes or [r for r in references if r["status"] != "安全"]:
            print("\n這是檢查模式，沒有更動任何檔案。要實際重編請加 --apply。")
        return changes

    updated = apply_changes(paragraphs, changes, references, args.rewrite_refs)
    write_output(updated, args.regulation_file, args.outdir, args.prefix)

    dangerous = [r for r in references if r["status"] == "危險"]
    if dangerous:
        print("\n⚠ 仍有 %d 處交叉引用引用到已刪除的款目，本程式沒有改動它們，"
              "請務必人工確認後再送出。" % len(dangerous))

    return changes


if __name__ == "__main__":
    main()
