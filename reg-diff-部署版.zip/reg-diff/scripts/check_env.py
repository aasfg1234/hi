# -*- coding: utf-8 -*-
"""
Step 0：環境檢查工具

檢查這個環境裝了哪些加分套件，缺的可以自動安裝。
核心功能一個套件都不需要，這支只是告訴你「現在能做到什麼」。
建議每次開始比對之前先跑一次。

使用方式：
    python check_env.py              檢查並安裝加分套件（需要能連外裝套件的環境）
    python check_env.py --no-install 只檢查不安裝，列出目前能做什麼

結束代碼：一律回 0。核心功能不依賴任何套件，少裝套件不是失敗。

--------------------------------------------------------------------------
套件庫固定的環境請用 --no-install
--------------------------------------------------------------------------
很多企業 AI 平台的執行環境沒有 pip、也裝不了套件。那裡嘗試安裝只會失敗，
甚至因為連不到外網而卡住。用 --no-install 直接看「現在能做什麼」比較實在。

核心功能（精確比對、跨章節重複條文、品質檢查、款目重編、同義詞正規化）
完全不依賴外部套件，一個都沒裝也照跑。
"""

import argparse
import importlib
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import setup_console


# 加分套件：裝了更好，但核心功能一個都不依賴它們。
# 刻意不叫「必要」——它們缺席時程式照跑，只是 Word 輸出改成 CSV、Step 2 變慢。
# key 是 import 時的名字，value 是 pip 安裝時的名字。
# 這兩個常常不一樣(import docx / pip install python-docx)，很容易搞混，這裡對應好。
ENHANCING_PACKAGES = {
    "docx": "python-docx",
    "rapidfuzz": "rapidfuzz",
}

# 選用套件：目前沒有。語意相似度那一步已移除——它需要 PyTorch 與可連外下載
# 的預訓練模型，企業 AI 平台幾乎一定不可用；改用同義詞正規化（見 synonyms.json）
# 達到類似效果，而且結果可稽核、法遵人員自己就能維護。
OPTIONAL_PACKAGES = {}


def is_installed(import_name):
    """檢查套件是不是已經裝好了。"""
    # 不是只接 ImportError：套件裝壞時 import 可能丟出各種例外，
    # 環境檢查本身掛掉是最沒道理的失敗方式。
    try:
        importlib.import_module(import_name)
        return True
    except Exception:
        return False


def pip_supports_break_system_packages():
    """
    這台電腦的 pip 認不認得 --break-system-packages 這個參數。

    這個參數是 pip 23.0 才加的，用來繞過某些 Linux 發行版「不准動系統 Python」的
    保護。舊版 pip 看到會直接報 usage error 整個失敗。舊版本的程式無條件加這個參數，
    在 pip < 23 的機器上第一次安裝一定失敗（雖然有 fallback 接住，但白跑一趟、
    而且註解宣稱「加了也不會有問題」是錯的）。這裡先問過 pip 版本再決定。
    """
    try:
        import pip
        parts = pip.__version__.split(".")
        return int(parts[0]) >= 23
    except Exception:
        return False


def install_package(pip_name):
    """安裝套件。回傳 True/False。"""
    print("  正在安裝 %s ..." % pip_name)
    command = [sys.executable, "-m", "pip", "install", pip_name, "-q"]
    if pip_supports_break_system_packages():
        command.insert(-1, "--break-system-packages")

    try:
        subprocess.check_call(command)
        print("  ✓ %s 安裝完成" % pip_name)
        return True
    except subprocess.CalledProcessError as exc:
        print("  ✗ %s 安裝失敗（結束代碼 %s）" % (pip_name, exc.returncode))
        print("    請手動執行：pip install %s" % pip_name)
        print("    若公司網路需要走 proxy，請洽資訊單位取得 pip 的 proxy 設定方式。")
        return False
    except Exception as exc:
        print("  ✗ %s 安裝失敗：%s" % (pip_name, exc))
        return False


def check_and_install(package_dict, auto_install=True, required=True):
    """檢查一組套件；auto_install=True 的話缺的就裝。回傳是否全部就緒。"""
    all_ok = True
    for import_name, pip_name in package_dict.items():
        if is_installed(import_name):
            print("  ✓ %s 已安裝" % pip_name)
            continue

        if not auto_install:
            print("  － %s 尚未安裝（預設不自動安裝）" % pip_name)
            all_ok = False
            continue

        print("  ✗ %s 尚未安裝，開始自動安裝..." % pip_name)
        if not install_package(pip_name):
            all_ok = False
            if required:
                print("    ⚠ 沒裝好的話：python-docx 影響 Word 輸出、"
                      "rapidfuzz 只影響速度，核心比對仍可執行")
    return all_ok


# 各功能需要哪些套件。用來在裝不了套件的環境裡，明確告訴使用者「現在能做什麼」，
# 而不是讓他跑到一半才發現某一步不能用。
CAPABILITIES = [
    ("讀 .txt / .md 內規", [], "標準函式庫即可"),
    ("讀 .docx 內規（含追蹤修訂）", [],
     "一律用內建 XML 解析，不經過 python-docx，裝不裝結果都一樣"),
    ("Step 1 精確比對與 CSV 對照表", [], "標準函式庫即可"),
    ("Step 0.5 款目重編與交叉引用", [], "標準函式庫即可"),
    ("Step 1.6 條文品質檢查（十項）", [], "標準函式庫即可"),
    ("Step 2 跨章節重複條文", [], "沒有 rapidfuzz 時改用內建 difflib，慢約十倍且候選數略有出入"),
    ("Step 2 同義詞正規化", [], "用 synonyms.json，純文字比對，不需要任何模型"),
    ("輸出 Word 對照表與標註版全文", ["docx"], "需要 python-docx，沒有就只產 CSV 與純文字"),
]


def report_capabilities():
    """
    只檢查不安裝，列出目前環境下哪些功能可用。

    給套件庫固定的企業平台用。在那種環境裡嘗試 pip install 只會失敗，
    甚至可能因為連不到外網而卡住；使用者真正需要知道的是「現在能做什麼」。
    """
    print("=" * 62)
    print("環境能力檢查（只檢查、不安裝）")
    print("Python %s" % sys.version.split()[0])
    print("=" * 62)

    print("\n【套件狀態】")
    for import_name, pip_name in list(ENHANCING_PACKAGES.items()) + list(OPTIONAL_PACKAGES.items()):
        print("  %s %s" % ("✓ 有" if is_installed(import_name) else "－ 無", pip_name))

    print("\n【目前可用的功能】")
    unavailable = []
    for name, needs, note in CAPABILITIES:
        missing = [n for n in needs if not is_installed(n)]
        if missing:
            unavailable.append((name, note))
        else:
            print("  ✓ %s" % name)
            if note and not needs:
                print("      %s" % note)

    if unavailable:
        print("\n【目前不可用的功能】")
        for name, note in unavailable:
            print("  ✗ %s" % name)
            print("      %s" % note)

    core_ok = True   # 核心比對完全不依賴外部套件
    print("\n" + "=" * 62)
    print("核心功能（精確比對、跨章節重複條文、品質檢查、款目重編）%s"
          % ("完全可用" if core_ok else "不可用"))
    print("這些功能只用標準函式庫，不需要安裝任何套件。")
    print("=" * 62)
    return core_ok


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 0：環境檢查")
    parser.add_argument("--no-install", action="store_true",
                        help="只檢查不安裝，並列出在目前套件狀態下哪些功能可用、哪些不可用。"
                             "套件庫固定的企業平台（例如 SPADE 這類沙箱環境）請用這個模式")
    args = parser.parse_args()

    if args.no_install:
        return report_capabilities()

    print("=" * 60)
    print("環境檢查開始")
    print("Python %s" % sys.version.split()[0])
    print("=" * 60)

    print("\n【加分套件】裝了會更好，但核心功能沒有它們也照跑")
    installed_ok = check_and_install(ENHANCING_PACKAGES, auto_install=True, required=True)

    print("\n" + "=" * 60)
    if installed_ok:
        print("✓ 加分套件都裝好了：Word 對照表會有紅字格式，Step 2 也會跑比較快")
    else:
        print("－ 有加分套件沒裝成功。核心比對照樣可以跑，只是 Word 對照表")
        print("  改成只出 CSV、Step 2 改用內建 difflib。要完整格式再手動裝。")

    print("=" * 60)

    # 核心功能不依賴任何套件，所以裝不起來不算失敗——一律回 0。
    # 回 1 會讓外層包裝把「少裝一個加速套件」誤判成「這個 skill 掛了」。
    return True


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
