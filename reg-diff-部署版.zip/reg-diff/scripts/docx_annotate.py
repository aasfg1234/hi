# -*- coding: utf-8 -*-
"""
在「原檔」上標註，而不是另外生一份新的 Word 檔。

--------------------------------------------------------------------------
為什麼要有這支
--------------------------------------------------------------------------
早期版本的標註版全文是開一份空白 Word、把文字一段一段倒進去。文字是對的，
但原檔的東西全部不見：實測一份普通的內規，11 項格式裡掉了 10 項——

    字型（標楷體）、字級、首行縮排、頁首、頁尾、頁面邊界、
    以及整張附表（表格直接消失）

法遵拿到那份檔案沒辦法用。對照表可以是新做的表格，但「標註版全文」的意思
就是「你原本那份，只是把改動標起來」，格式跑掉就失去意義了。

這支的做法是：**把原檔複製一份，只動有改到的那幾段裡面的文字**。
沒改到的段落一個位元組都不碰，表格、頁首頁尾、樣式、頁面設定自然全部留著。

--------------------------------------------------------------------------
只用標準函式庫
--------------------------------------------------------------------------
.docx 就是一個 zip，內容在 word/document.xml。用 zipfile ＋ xml.etree 就夠了。

這件事有額外的好處：套件庫固定的平台（例如 SPADE）裝不了 python-docx，
以前在那種環境完全產不出 Word 檔，現在產得出來，而且格式比以前更完整。

--------------------------------------------------------------------------
做不到的事
--------------------------------------------------------------------------
- 輸入不是 .docx（例如 .txt）時沒有原檔可改，會退回舊的「新建一份」做法
- 表格儲存格內含多段文字時，那一格不標記（會回報幾格沒標）
- 不寫成 Word 的「追蹤修訂」，是直接把顏色與底線刪除線套上去。
  追蹤修訂要另外處理 rsid 與作者資訊，而且法遵要的是可以直接列印的版本。
"""

import copy
import os
import re
import shutil
import zipfile
import xml.etree.ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_W = "{%s}" % W


def _register_namespaces(xml_bytes):
    """
    先把原檔宣告過的命名空間前綴全部註冊回去，再解析。

    不做這件事的話，ElementTree 會自己編出 ns0、ns1 這種前綴。Word 檔常有
    mc:Ignorable="w14 w15 wp14" 這種欄位在指名前綴，前綴一被改掉，Word 開檔
    就會說檔案毀損。
    """
    head = xml_bytes[:4000].decode("utf-8", "replace")
    for prefix, uri in re.findall(r'xmlns:([A-Za-z0-9_.-]+)\s*=\s*"([^"]+)"', head):
        try:
            ET.register_namespace(prefix, uri)
        except ValueError:
            pass
    default = re.search(r'xmlns\s*=\s*"([^"]+)"', head)
    if default:
        try:
            ET.register_namespace("", default.group(1))
        except ValueError:
            pass


def _paragraph_text(paragraph):
    """跟 _common._docx_paragraph_text 一致：把 <w:t> 串起來。這裡不 strip。"""
    return "".join(node.text or "" for node in paragraph.iter(_W + "t"))


def collect_slots(body):
    """
    照 read_docx_stdlib 的順序把段落列出來：先本文段落，再表格儲存格。

    順序必須跟讀檔那邊一模一樣，否則標註會標到別段去——那比不標還糟。
    """
    slots = []
    tables = []
    for child in body:
        if child.tag == _W + "p":
            if _paragraph_text(child).strip():
                slots.append({"kind": "p", "p": child, "parent": body})
        elif child.tag == _W + "tbl":
            tables.append(child)

    for table in tables:
        for row in table.iter(_W + "tr"):
            for cell in row.iter(_W + "tc"):
                paras = [p for p in cell.iter(_W + "p")]
                joined = "\n".join(_paragraph_text(p).strip()
                                   for p in paras).strip()
                if joined:
                    filled = [p for p in paras if _paragraph_text(p).strip()]
                    slots.append({"kind": "cell", "p": filled[0] if len(filled) == 1 else None,
                                  "parent": cell, "count": len(filled)})
    return slots


# ---------------------------------------------------------------------------
# 取出每個字目前套的格式
# ---------------------------------------------------------------------------

def _visible_runs(paragraph):
    """
    段落裡「看得到的」run，依序回傳 (run 元素, 文字)。

    <w:del> 底下的 run 放的是 <w:delText>，那是已經被刪掉的文字，不算在內。
    """
    runs = []
    for run in paragraph.iter(_W + "r"):
        text = "".join(t.text or "" for t in run.findall(_W + "t"))
        if text:
            runs.append((run, text))
    return runs


# ---------------------------------------------------------------------------
# 產生標記過的 run
# ---------------------------------------------------------------------------

def _make_run(text, base_rpr, mark):
    """
    做一個 <w:r>。base_rpr 是原本的格式，mark 是要加上的標示（可以是 None）。

    先複製原本的格式再疊上標示，字型與字級才不會掉。
    """
    run = ET.Element(_W + "r")
    rpr = copy.deepcopy(base_rpr) if base_rpr is not None else ET.Element(_W + "rPr")

    if mark:
        for tag in ("color", "u", "strike"):
            for old in rpr.findall(_W + tag):
                rpr.remove(old)
        color = ET.SubElement(rpr, _W + "color")
        color.set(_W + "val", str(mark.get("顏色", "C00000")).lstrip("#"))
        if mark.get("底線"):
            underline = ET.SubElement(rpr, _W + "u")
            underline.set(_W + "val", "single")
        if mark.get("刪除線"):
            strike = ET.SubElement(rpr, _W + "strike")
            strike.set(_W + "val", "1")

    if len(rpr):
        run.append(rpr)

    node = ET.SubElement(run, _W + "t")
    node.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    node.text = text
    return run


def _segments_with_format(diff_parts, rpr_per_char, offset):
    """
    把字級差異片段配上原本的格式。

    diff_parts 是 [(種類, 文字), ...]，種類為 equal／insert／delete。
    回傳 [(種類, 文字, rPr, 從第幾個字開始), ...]——位置是用來把書籤、圖片、
    分頁符這些非文字元素插回原來的相對位置。
    equal 與 insert 的文字來自新版，可以直接對到新版原檔的第幾個字；
    delete 的文字在新版裡不存在，就沿用游標當下位置的格式。
    """
    out = []
    pos = offset
    for kind, text in diff_parts:
        if not text:
            continue
        if kind == "delete":
            rpr = rpr_per_char[min(pos, len(rpr_per_char) - 1)] if rpr_per_char else None
            out.append((kind, text, rpr, pos))
            continue

        # 同一段文字中間格式若有變（例如其中兩個字是粗體），要拆開才保得住
        start = 0
        while start < len(text):
            idx = pos + start
            rpr = rpr_per_char[idx] if idx < len(rpr_per_char) else None
            end = start + 1
            while end < len(text):
                nxt = pos + end
                nxt_rpr = rpr_per_char[nxt] if nxt < len(rpr_per_char) else None
                if nxt_rpr is not rpr:
                    break
                end += 1
            out.append((kind, text[start:end], rpr, pos + start))
            start = end
        pos += len(text)
    return out


def _scan_paragraph(paragraph):
    """
    把一段拆成「文字」與「不是文字的東西」兩類，並記下後者卡在第幾個字。

    段落裡除了文字還有一堆東西：書籤、圖片、分頁符、域代碼、註解錨點。
    早期版本重寫段落時把 <w:pPr> 以外的子元素全部清掉再放新文字，
    實測一份含這些元素的內規，**分頁符與書籤直接消失**。

    書籤消失最嚴重：內規常用交叉參照欄位指向書籤，書籤沒了之後
    Word 會在那裡印出「錯誤! 找不到參照來源」，等於把原檔弄壞。

    回傳 (完整文字, 每個字的 rPr, [(卡在第幾個字, 要保留的元素), ...])
    """
    text_parts, rpr_per_char, keepers = [], [], []
    pos = 0
    for child in paragraph:
        if child.tag == _W + "pPr":
            continue
        if child.tag == _W + "r":
            rpr = child.find(_W + "rPr")
            text = "".join(t.text or "" for t in child.findall(_W + "t"))
            others = [c for c in child
                      if c.tag not in (_W + "rPr", _W + "t")]
            if text:
                text_parts.append(text)
                rpr_per_char.extend([rpr] * len(text))
                pos += len(text)
            if others:
                # 同一個 run 裡文字與圖片並存時，把非文字的部分單獨留一個 run，
                # 位置排在那段文字後面，順序才不會跑掉
                shell = ET.Element(_W + "r")
                if rpr is not None:
                    shell.append(copy.deepcopy(rpr))
                for node in others:
                    shell.append(copy.deepcopy(node))
                keepers.append((pos, shell))
            continue

        # 書籤、域代碼、超連結、註解錨點……原封不動留著
        keepers.append((pos, copy.deepcopy(child)))

    return "".join(text_parts), rpr_per_char, keepers


def _rewrite_paragraph(paragraph, diff_parts, marks, expect=None):
    """
    把一段的文字換成標記過的 run。

    段落設定（<w:pPr>：縮排、行距、對齊、樣式）留著，
    段落裡的書籤、圖片、分頁符、域代碼也留著，而且留在原來的相對位置。
    """
    raw, rpr_per_char, keepers = _scan_paragraph(paragraph)

    # 防呆：這一段「直接放著的文字」必須就是我們要改的那一段。
    #
    # 對不上的典型情形是文字方塊：條文放在 <w:txbxContent> 裡，
    # 讀檔時用遞迴看得到，標註時只看直接子層看不到。硬標下去的結果是
    # 原本的文字留著、標記過的文字又疊上去，**同一條會印兩次**。
    # 那比不標還糟，所以對不上就整段不動，交給呼叫端回報。
    if expect is not None and raw.strip() != expect.strip():
        return False

    offset = len(raw) - len(raw.lstrip())

    pieces = _segments_with_format(diff_parts, rpr_per_char, offset)

    # 只清內容，<w:pPr> 一定要留
    for child in list(paragraph):
        if child.tag != _W + "pPr":
            paragraph.remove(child)

    kept = list(keepers)

    def flush_before(position):
        while kept and kept[0][0] <= position:
            paragraph.append(kept.pop(0)[1])

    for kind, text, rpr, start in pieces:
        if kind == "delete":
            # 刪掉的字在新版裡不佔位置，只要把它之前的元素放回去就好
            flush_before(start)
            paragraph.append(_make_run(text, rpr, marks.get("刪除")))
            continue

        mark = marks.get("新增") if kind == "insert" else None
        cursor, rest = start, text
        while rest:
            flush_before(cursor)
            # 元素若卡在這段文字「中間」，就把文字切開，元素才會留在原位。
            # 只在段落邊界插入的話，句子中間的圖片會被推到整段最後面。
            nxt = kept[0][0] if kept else None
            if nxt is not None and cursor < nxt < cursor + len(rest):
                take = nxt - cursor
            else:
                take = len(rest)
            paragraph.append(_make_run(rest[:take], rpr, mark))
            cursor += take
            rest = rest[take:]

    for _, element in kept:
        paragraph.append(element)
    return True


def _deleted_paragraph(template, text, marks):
    """
    整段被刪掉的條文，在新版裡沒有對應段落，要新做一段插進去。

    段落設定從鄰近那一段複製，這樣縮排與樣式才跟上下文一致，
    不會突然變成一段靠左頂格的文字。
    """
    para = ET.Element(_W + "p")
    if template is not None:
        ppr = template.find(_W + "pPr")
        if ppr is not None:
            para.append(copy.deepcopy(ppr))
    base = None
    if template is not None:
        runs = _visible_runs(template)
        if runs:
            base = runs[0][0].find(_W + "rPr")
    para.append(_make_run(text, base, marks.get("刪除")))
    return para


# ---------------------------------------------------------------------------
# 對外入口
# ---------------------------------------------------------------------------

def annotate_in_place(source_docx, results, output_path, marks, diff_runs):
    """
    複製 source_docx，只把有改到的段落標記起來，寫到 output_path。

    回傳一份摘要 dict，說明標了幾段、有幾段標不到——標不到的一定要講，
    不能讓人以為「沒有紅字就是沒有改」。
    """
    with zipfile.ZipFile(source_docx) as archive:
        names = archive.namelist()
        if "word/document.xml" not in names:
            raise ValueError("不是有效的 .docx：找不到 word/document.xml")
        payload = {n: archive.read(n) for n in names}
        infos = {i.filename: i for i in archive.infolist()}

    xml_bytes = payload["word/document.xml"]
    _register_namespaces(xml_bytes)
    root = ET.fromstring(xml_bytes)
    body = root.find(_W + "body")
    if body is None:
        raise ValueError("不是有效的 .docx：找不到 <w:body>")

    slots = collect_slots(body)
    summary = {"marked": 0, "skipped_cells": 0, "inserted": 0,
               "unmatched": 0, "mismatch": 0, "slots": len(slots)}

    changed = [r for r in results if r["type"] != "unchanged"]

    # 先處理有對應段落的（修改、新增、編號調整），刪除的最後再插入，
    # 免得先插入改變了後面段落的位置
    for r in changed:
        if r["type"] == "deleted":
            continue
        idx = r.get("new_index")
        if not idx or idx > len(slots):
            summary["unmatched"] += 1
            continue
        slot = slots[idx - 1]
        if slot["p"] is None:
            summary["skipped_cells"] += 1
            continue

        if r["type"] == "added":
            parts = [("insert", r["new_text"])]
        else:
            parts = diff_runs(r["old_text"] or "", r["new_text"] or "")
        if _rewrite_paragraph(slot["p"], parts, marks,
                              expect=r.get("new_text")):
            summary["marked"] += 1
        else:
            summary["mismatch"] += 1

    # 刪掉的條文插在它原本的位置附近
    for r in changed:
        if r["type"] != "deleted" or not r.get("old_text"):
            continue
        anchor = None
        for after in results[results.index(r) + 1:]:
            j = after.get("new_index")
            if j and j <= len(slots) and slots[j - 1]["p"] is not None:
                anchor = slots[j - 1]
                break
        if anchor is None:
            for before in reversed(results[:results.index(r)]):
                j = before.get("new_index")
                if j and j <= len(slots) and slots[j - 1]["p"] is not None:
                    anchor = slots[j - 1]
                    break
        if anchor is None:
            summary["unmatched"] += 1
            continue

        parent = anchor["parent"]
        para = _deleted_paragraph(anchor["p"], r["old_text"], marks)
        children = list(parent)
        if anchor["p"] in children:
            parent.insert(children.index(anchor["p"]), para)
            summary["inserted"] += 1
        else:
            summary["unmatched"] += 1

    payload["word/document.xml"] = ET.tostring(root, encoding="UTF-8",
                                               xml_declaration=True)

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as out:
        for name in names:
            info = infos[name]
            item = zipfile.ZipInfo(name, date_time=info.date_time)
            item.compress_type = info.compress_type
            item.external_attr = info.external_attr
            out.writestr(item, payload[name])

    return summary
