# -*- coding: utf-8 -*-
"""
Step 2：跨章節重複條文抓取工具（模糊字串比對）── 整個流程最重要的一步

目的：
你修改了某一條規定，但同一個規定因為內規結構的關係，可能在別的章節
(壽險、產險、網路投保……)也各寫了一次，用詞因為實務作業需求略有調整。
只改一處就會漏改。這支程式把你改過的段落拿去跟全文其他段落比相似度，
把有嫌疑的都列出來，交給人工判斷。

原則：寧可多列、不要漏列。法規漏改的代價遠高於多花時間看候選清單。

--------------------------------------------------------------------------
重要：要傳「新版全文」，不是舊版
--------------------------------------------------------------------------
regulation_file 請傳「你已經改好的新版內規全文」。
傳舊版的話，你剛改掉的那一條的舊文字會以極高相似度霸佔候選第一名，
每一筆都被同一個假陽性佔位，等於白跑。

--------------------------------------------------------------------------
關於中文的相似度計算（跟舊版本的差別）
--------------------------------------------------------------------------
跟舊版有三個地方不一樣：

1) 不再用 token_sort_ratio。舊版用它並宣稱「即使詞語順序不一樣也能抓出相似度」，
   這對中文是錯的：token_sort 是靠空白切詞的，中文整句沒有空白會被當成單一 token，
   分數退化成跟 ratio 一模一樣（實測 token_sort / token_set / ratio 三者同分）。
   現在直接用 ratio，不再宣稱做不到的事。

2) 比對前先把條號拿掉。條號不是條文內容，卻會干擾分數——「第三條」對上
   「第二十二條」光這幾個字就先扣一截。實測拿掉條號後，真正相關的條文分數幾乎
   不動(53.1 -> 51.3)，不相干的卻從 22~32 掉到 11~18，訊號雜訊比明顯拉開。

3) 門檻從 70 下修到 45。實測資料：
     「逾期未繳超過三十日者，契約停止效力」
     vs「逾期未繳者，契約停止效力」              同一條漏改  83.9 分
     vs「保險費未於到期日後未繳納者，契約效力停止」 換句話說   51.3 分
     vs 同一份內規裡其他不相干條文                          11~18 分
   舊門檻 70 會漏掉「換句話說」那一類，正好就是本步驟要抓的東西；而 45 距離
   雜訊帶(18)還有很大的空間。原則是寧可多列、不要漏列。

代價是法規慣用語(「本公司應於……」「要保人應……」)會讓不相干的條文分數偏高。
所以輸出多附一欄「最長共同片段」：
  - 分數高、共同片段也長  → 很可能是真的重複條文
  - 分數高、共同片段很短  → 多半只是公文套語像，可以快速跳過
這一欄是給人看的分流線索，不參與門檻判斷。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
三種指定「你改了哪一段」的方法，擇一即可：

1) 直接貼上修改後的文字：
     python fuzzy_duplicate_finder.py 新版全文.docx "第三條 逾期未繳超過三十日者……"

2) 指定它在新版全文裡的段次（就是 Step 1 產出的 CSV 裡「新版段次」那一欄）：
     python fuzzy_duplicate_finder.py 新版全文.docx --changed-line 4

3) 一次跑完 Step 1 抓到的所有修改段落（實務上都用這個，不用手動跑 N 次）：
     python fuzzy_duplicate_finder.py 新版全文.docx --from-csv 修正對照表.csv

可調參數：
     --threshold 45   相似度門檻，調低抓得廣、雜訊多；調高會漏
     --top 15         每個修改段落最多列幾筆候選
"""

import argparse
import csv
import re
import difflib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     extract_article_no, format_scope, load_synonyms,
                     normalize_terms, strip_article_no, synonym_evidence,
                     resolve_output, load_table_format,
                     diff_runs as _diff_runs)

try:
    from rapidfuzz import fuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

DEFAULT_THRESHOLD = 45.0
DEFAULT_TOP = 15

# 候選條文要附帶前後各幾段。1 段通常就夠看出它在那一章裡的位置。
DEFAULT_CONTEXT = 1


def calc_similarity(text_a, text_b):
    """
    兩段文字的相似度，0~100，越高越像。傳進來的應該是已經去掉條號的條文本體。

    用 ratio(單純比字元重疊)。理由見檔頭說明：對中文而言 rapidfuzz 的
    token_sort_ratio / token_set_ratio 會退化成 ratio，用它們只是自欺欺人。
    沒裝 rapidfuzz 就退回 Python 內建 difflib，演算法相近，只是慢一點。
    """
    if HAS_RAPIDFUZZ:
        return float(fuzz.ratio(text_a, text_b))
    return difflib.SequenceMatcher(None, text_a, text_b).ratio() * 100.0


# 相似度高到這個程度時，「片段不是從句首開始」就不再是套語的訊號。
# 實測 152 筆候選：80 分以上的 107 筆片段全部從句首開始，套語假陽性最高只到 79.4 分。
# 但真實案例會出現高分卻非句首的情形——「以書面通知」對上「以電子方式通知」，
# 差異落在句子前段，最長片段就被推到句中，分數卻有 94.4，而且是真的重複條文。
HIGH_CONFIDENCE = 80.0


def longest_common_fragment(text_a, text_b):
    """
    兩段文字最長的一段完全相同的連續文字，以及這段文字從哪裡開始。

    回傳 (片段, 位置)，位置是「句首」「句中」或「句尾」。

    為什麼要標位置：
    片段長度單獨看會騙人。實測一份 50 頁的內規：真正被抄到別章的重複條文，
    共同片段 21 字；而一堆毫不相干的條文因為都用同一個句尾套語（「，作為內部
    控制制度有效運作之依據；但金額未達新臺幣十萬元者，得由單位主管逕行核定」），
    共同片段有 40 字，比真的重複還長。只看長度會把套語排在真貨前面。

    改看「片段從哪裡開始」就分得開了。同一份實測資料的 77 筆候選中：
        片段不是從句首開始的 44 筆 —— 全部是套語假陽性，沒有一筆是真的
        片段從句首開始的 33 筆 —— 包含全部 2 筆真的重複，其餘仍需人工判斷
    也就是說，這是個可靠的「排除」訊號，不是「確認」訊號：非句首幾乎可以直接
    跳過，句首則還是要看內容。

    但這個結論有分數上限。同一份資料裡非句首的候選最高只到 79.4 分，
    80 分以上的 107 筆全部是句首。實際案例出現過 94.4 分的非句首候選
    （「以書面通知」對「以電子方式通知」，差異在句子前段），那是真的重複條文。
    所以「非句首＝套語」只在 HIGH_CONFIDENCE 以下成立，高分時不能拿它叫人跳過。
    """
    matcher = difflib.SequenceMatcher(None, text_a, text_b)
    match = matcher.find_longest_match(0, len(text_a), 0, len(text_b))
    fragment = text_a[match.a:match.a + match.size]
    if not fragment:
        return "", ""

    # 容許兩個字的誤差，開頭的主詞用字差異不影響判斷
    if match.a <= 2 and match.b <= 2:
        return fragment, "句首"
    # 落在候選條文後 40% 才開始的，通常就是但書、目的語那一段
    if match.b >= len(text_b) * 0.6:
        return fragment, "句尾"
    return fragment, "句中"


def neighbours(all_paragraphs, index, span):
    """
    候選條文的前後文。index 是 0 起算的位置。

    為什麼需要：
    實測真實內規時發現，「並陳報主管覆核」這類句子在整份文件裡到處都是，
    光看分數與片段位置分不出「這是漏改」還是「這兩個作業的核准層級本來就不同」。

        第六條　分行辦理房屋貸款……並陳報分行經理覆核。
        第七條　分行辦理車輛貸款……並陳報分行經理覆核。
        第十三條　區域中心辦理房屋貸款……並陳報區域中心主管覆核。

    改了第六條，上面兩條都會被列成候選，但只有第十三條該一起看
    （同樣是房貸），第七條是不同業務，不該動。

    前後文看得出這一條在它那一章裡的位置：第十三條前面是個人信用貸款、
    後面是車輛貸款，跟第六條所在的第一章結構平行——這個訊號程式判斷不了，
    但 LLM 看得懂。
    """
    if span <= 0:
        return "", ""
    before = [p.strip() for p in all_paragraphs[max(0, index - span):index]]
    after = [p.strip() for p in all_paragraphs[index + 1:index + 1 + span]]
    return " ／ ".join(x for x in before if x), " ／ ".join(x for x in after if x)


def changed_fragments(old_text, new_text, diff_runs, min_len=2):
    """
    這次修改「加了哪幾段字」。回傳片段清單。

    只取新增的部分。刪除的部分沒辦法拿去別條找——那些字本來就不該存在了。
    """
    if not old_text or not new_text:
        return []
    out = []
    for kind, text in diff_runs(old_text, new_text):
        if kind != "insert":
            continue
        piece = text.strip("，、。；：（）()　 ")
        if len(piece) >= min_len:
            out.append(piece)
    return out


def coverage_note(fragments, candidate_body, normalize, synonyms):
    """
    這次新增的那幾段字，候選條文裡有沒有。

    --------------------------------------------------------------------
    為什麼這一項比「業務相不相同」重要
    --------------------------------------------------------------------
    實測過一個會漏判的情境：某條加了「至少五年」的保存期限，
    其他三條分別講信貸、車貸、信用卡——**業務全都不同**，
    但那三條也都寫「並留存電子紀錄」，也都該加保存期限。

    如果照「業務不同就不用改」去篩，這三條會全部被漏掉。

    真正該問的不是「業務同不同」，是「**你這次加的東西，那一條有沒有**」。
    這件事程式量得出來，不必交給判斷。

    回傳三種結果：
        ""              沒有可比的新增內容（例如整條新增、整條刪除）
        "候選也有：…"    候選條文已經有這些內容，多半不用動
        "候選缺少：…"    候選缺這些內容，**這是最該看的一種**
    """
    if not fragments:
        return ""

    body = candidate_body or ""
    body_norm = normalize(body, synonyms)[0] if synonyms else body

    missing, present = [], []
    for piece in fragments:
        piece_norm = normalize(piece, synonyms)[0] if synonyms else piece
        if piece in body or piece_norm in body_norm:
            present.append(piece)
        else:
            missing.append(piece)

    if missing:
        note = "候選缺少：" + "、".join(missing[:5])
        if present:
            note += "（已有：%s）" % "、".join(present[:3])
        return note
    return "候選也有：" + "、".join(present[:5])


# 改動片段開頭常見的連接詞與虛字。這些不是要找的概念，要先剝掉，
# 否則「及火險保單」會拿「及」去搜，全文到處都是。
_LEADING = "及並或暨與且的之其該此本前後另應得須不亦仍即"
_TRAILING = "的之者等"

# 短到沒有辨識力的詞，拿去搜只會製造雜訊。
_TOO_COMMON = set((
    "規定 辦理 作業 事項 相關 有關 應予 予以 得予 本行 本公司 本要點 各款 前項 "
    "前條 該等 情形 方式 內容 資料 文件 紀錄 人員 單位 主管 機關 業務"
).split())


# 條號與款目編號。它們是編號不是概念，留著會讓「一、受託人授權書」
# 拿「一、」去搜，全文到處都是。
_NUMBERING = re.compile(
    r"^\s*(第\s*[零〇一二三四五六七八九十百千兩\d]+\s*[條點項款目章節]"
    r"(\s*之\s*[零〇一二三四五六七八九十百千兩\d]+)?"
    r"|[零〇一二三四五六七八九十百千兩\d]+\s*[、.]"
    r"|[（(]\s*[零〇一二三四五六七八九十百千兩\d]+\s*[）)])\s*")

# 改動片段長到這個程度，就不是「加了一個概念」而是整條改寫或整條新增，
# 那種情況相似度比對本來就抓得到，再用關鍵詞搜只會製造雜訊。
MAX_FRAGMENT = 20


def search_terms(fragment, min_len=2, max_terms=6):
    """
    從一段「這次改動的文字」抽出可以拿去搜的詞。

    只取**前綴與後綴**，不取中間的滑動窗。原因是中文沒有斷詞套件可用，
    中間的窗會切出「險保」這種跨詞碎片。實測用整句抽 n-gram，974 段的內規
    有 319 段命中（33%），完全不能用；只取前後綴就沒有這個問題，
    因為改動片段本身很短，而且是人寫出來的完整概念。

        「及火險保單」→ 剝掉「及」→「火險保單」
          前綴：火險、火險保、火險保單
          後綴：保單、險保單
          （不會產生「險保」這種碎片）
    """
    text = _NUMBERING.sub("", (fragment or "").strip())
    while text and text[0] in _LEADING:
        text = text[1:]
    while text and text[-1] in _TRAILING:
        text = text[:-1]
    text = text.strip("，、。；：（）()　 ")
    if not (min_len <= len(text) <= MAX_FRAGMENT):
        return []

    terms = []
    for n in range(len(text), min_len - 1, -1):
        for candidate in (text[:n], text[-n:]):
            if candidate not in terms and candidate not in _TOO_COMMON:
                terms.append(candidate)
    return terms[:max_terms]


def find_by_changed_text(fragments, all_paragraphs, exclude_index=None,
                         contexts=None, synonyms=None, normalize=None,
                         extract_article_no=None, format_scope=None,
                         top=10, max_ratio=0.05):
    """
    拿「這次改動的那幾個字」去搜全文，而不是拿整條去比相似度。

    --------------------------------------------------------------------
    為什麼整條比對不夠
    --------------------------------------------------------------------
    整條對整條時，分數被「沒改到的部分」主導，而那部分往往就是公文套語。
    真正該找的是改動涉及的概念在哪裡還有出現。

    實測：第六條加了「及火險保單」。同一份內規裡有

        第四十條　本行辦理擔保放款，應確認擔保品已投保火險……
        第四十一條　擔保品之保險單正本應由本行收執……

    這兩條講的就是火險與保單，直接相關。但整條比對只有 26.5 分與 16.7 分，
    在 45 分門檻下**一條都抓不到**。改用改動文字去搜就找得到。

    回傳依「命中的詞多長」排序——命中越長的詞，關聯越明確。
    """
    if not fragments:
        return []

    # 在全文命中太多段的詞，本身就沒有辨識力（「受託」「三十」這種），
    # 留著只會把整份文件都撈出來。用資料自己算，不用手工黑名單。
    limit = max(3, int(len(all_paragraphs) * max_ratio))

    def distinctive(term):
        hits = 0
        for paragraph in all_paragraphs:
            if term in paragraph:
                hits += 1
                if hits > limit:
                    return False
        return True

    term_sets = []
    for fragment in fragments:
        terms = [t for t in search_terms(fragment) if distinctive(t)]
        if terms:
            term_sets.append((fragment, terms))
    if not term_sets:
        return []

    hits = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        body_norm = (normalize(paragraph, synonyms)[0]
                     if (normalize and synonyms) else paragraph)

        matched = []
        for fragment, terms in term_sets:
            for term in terms:
                term_norm = (normalize(term, synonyms)[0]
                             if (normalize and synonyms) else term)
                if term in paragraph or term_norm in body_norm:
                    matched.append((fragment, term))
                    break        # 每個改動片段只記最長的那一個命中
        if not matched:
            continue

        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": line_no,
            "article_no": ((context["ref"] if context else "")
                           or (extract_article_no(paragraph)
                               if extract_article_no else "")),
            "scope": format_scope(context) if format_scope else "",
            "text": paragraph,
            "matched": matched,
            "strength": max(len(term) for _, term in matched),
        })

    hits.sort(key=lambda h: (h["strength"], -h["line_number"]), reverse=True)
    return hits[:top] if top and top > 0 else hits

def print_changed_text_hits(fragments, hits):
    """把「拿改動文字去搜」的結果印出來，跟相似度候選分開列。"""
    if not fragments:
        return
    print("")
    print("── 以這次改動的文字搜尋全文 ──")
    print("   改動片段：%s" % "、".join(fragments))
    if not hits:
        print("   全文沒有其他條文提到這些內容。")
        return
    print("   %d 條提到相同內容（整條相似度可能很低，但概念直接相關）：" % len(hits))
    for hit in hits:
        label = hit["article_no"] or ("第%d段" % hit["line_number"])
        scope = (hit["scope"] + " ") if hit["scope"] else ""
        terms = "、".join(term for _, term in hit["matched"])
        print("   [%s%s（第%d段）] 命中「%s」"
              % (scope, label, hit["line_number"], terms))
        print("      %s" % hit["text"])

def describe_difference(changed_body, candidate_body, diff_runs,
                        limit=8, pad=4):
    """
    兩條相似條文「差在哪」，逐處列出，格式是 `……〔異動→候選〕……`。

    這一項直接回答「這是漏改，還是兩個作業的層級本來就不同」：

        受理後〔三→五〕日內　　　　　　異動寫三日，候選寫五日
        〔分行經理→區域中心主管〕覆核　核准層級不同
        鑑價報告〔及火險保單→無〕，並　異動有、候選沒有

    看到只有層級用詞在變，人一眼就知道那是刻意分級；看到業務名稱也在變，
    就知道那兩條本來講的就不是同一件事。

    --------------------------------------------------------------------
    為什麼要帶前後幾個字
    --------------------------------------------------------------------
    早期版本只把兩邊各自獨有的文字列出來，而且「少於兩個字就跳過」——
    本意是去掉標點雜訊，結果把訊號一起丟了。實測這幾種差異全部顯示成空白：

        三日 vs 五日　　　　　　（期間）
        不得 vs 得　　　　　　　（責任用語）
        一百萬元 vs 三百萬元　　（金額）

    差異欄空白會讓人以為兩條一模一樣，那比不顯示更糟。
    現在一個字的差異也照列，靠前後各借幾個字讓它讀得懂。

    limit：最多列幾處差異；超過會明講還有幾處，不會安靜截斷。
    pad：每處差異前後各借幾個相同的字當脈絡。
    """
    # 方向固定是「異動條文 → 候選條文」。反過來寫的話，〔區域中心→分行〕
    # 會被讀成「變成」，但候選條文不是舊版、是另一條條文，那樣讀是錯的。
    parts = diff_runs(changed_body or "", candidate_body or "")

    segments = []
    i = 0
    while i < len(parts):
        if parts[i][0] == "equal":
            i += 1
            continue

        only_changed, only_candidate = [], []
        j = i
        while j < len(parts) and parts[j][0] != "equal":
            if parts[j][0] == "delete":
                only_changed.append(parts[j][1])      # 只有異動條文有
            else:
                only_candidate.append(parts[j][1])    # 只有候選條文有
            j += 1

        before = parts[i - 1][1][-pad:] if i > 0 and parts[i - 1][0] == "equal" else ""
        after = parts[j][1][:pad] if j < len(parts) and parts[j][0] == "equal" else ""
        cand = "".join(only_candidate)
        chg = "".join(only_changed)

        # 一律寫成〔異動→候選〕。缺的那一邊寫「無」，不用 ＋／－ 符號，
        # 那兩個符號在這裡容易被讀反。
        if chg and cand:
            body = "〔%s→%s〕" % (chg, cand)
        elif chg:
            body = "〔%s→無〕" % chg
        else:
            body = "〔無→%s〕" % cand
        segments.append(before + body + after)
        i = j

    if not segments:
        return ""
    if len(segments) <= limit:
        return "　".join(segments)
    # 截斷要講出來。安靜截斷會讓人以為只有這幾處不同。
    return "　".join(segments[:limit]) + "　（另有 %d 處差異未列出）" % (
        len(segments) - limit)


def find_duplicates(changed_text, all_paragraphs, threshold=DEFAULT_THRESHOLD,
                    top=DEFAULT_TOP, exclude_index=None, contexts=None,
                    synonyms=None, context_span=DEFAULT_CONTEXT,
                    changed_old_text=None):
    """
    拿修改過的文字去跟全文每一段比，回傳超過門檻的候選清單。

    exclude_index：要跳過的段次(從 1 起算)，通常就是被修改的那一段自己。
    沒指定的話，退而求其次跳過「文字完全相同」的段落。

    contexts：build_hierarchy() 算出的層級脈絡。有給的話，候選的條號會寫成
    「第三十三條第二款第二目」而不是只有「(二)」——候選清單是要拿去人工核對的，
    寫「(二)」等於叫人在 50 頁裡自己找。

    synonyms：同義詞表。有給的話，比對前先把「應繳金額」這類變體收斂成
    「保險費」，才抓得到用詞完全換掉的重複條文（實測 34 分拉到 56 分）。
    每一筆候選會一併記錄是哪一組詞讓它配對上的——不能只給分數不給理由。
    """
    changed_body = strip_article_no(changed_text)
    # 這次「加了哪幾段字」。拿去每個候選裡找，找不到的就是最該看的那幾條。
    added = changed_fragments(strip_article_no(changed_old_text or ""),
                              changed_body, _diff_runs)
    changed_norm, changed_applied = normalize_terms(changed_body, synonyms)

    candidates = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        if exclude_index is None and paragraph == changed_text:
            continue

        paragraph_body = strip_article_no(paragraph)
        paragraph_norm, paragraph_applied = normalize_terms(paragraph_body, synonyms)

        # 分數一律用正規化後的文字算。沒有同義詞命中時，正規化後就等於原文，
        # 分數也就等於純字面比對，不會憑空灌水。
        score = calc_similarity(changed_norm, paragraph_norm)
        if score >= threshold:
            # 分數用正規化後的文字算，但「共同片段」一定要用原文算。
            # 正規化會把「停止效力」換成代表詞「終止」，拿正規化後的片段去顯示，
            # 人工複核時把那段字複製到文件裡搜尋會完全找不到——
            # 一個叫人去核對的工具，給的線索必須是文件裡真的有的字。
            fragment, position = longest_common_fragment(changed_body, paragraph_body)
            context = contexts[idx] if contexts else None
            evidence = synonym_evidence(changed_applied, paragraph_applied,
                                        changed_body, paragraph_body,
                                        synonyms or [])
            candidates.append({
                "line_number": line_no,
                "article_no": ((context["ref"] if context else "")
                               or extract_article_no(paragraph)),
                "scope": format_scope(context),
                "text": paragraph,
                "similarity": round(score, 1),
                "common_fragment": fragment,
                "fragment_len": len(fragment),
                "fragment_position": position,
                "synonym_evidence": evidence,
                # 前後文與「差在哪」：光看分數分不出「漏改」與「層級本來就不同」，
                # 這兩項是給 LLM 判斷用的材料，不是給程式判斷的。
                "context_before": neighbours(all_paragraphs, idx, context_span)[0],
                "context_after": neighbours(all_paragraphs, idx, context_span)[1],
                "difference": describe_difference(changed_body, paragraph_body,
                                                  _diff_runs),
                # 比「業務同不同」更關鍵：這次加的字，這一條有沒有
                "coverage": coverage_note(added, paragraph_body,
                                          normalize_terms, synonyms),
            })

    # 排序以相似度為主。同分時，共同片段從句首開始的排前面——實測顯示真正的
    # 重複條文都在這一類，非句首的則全是套語假陽性。
    candidates.sort(
        key=lambda c: (c["similarity"],
                       1 if c.get("fragment_position") == "句首" else 0,
                       c["fragment_len"]),
        reverse=True)
    return candidates[:top] if top and top > 0 else candidates


def print_candidates(changed_text, candidates, threshold):
    """把候選清單印出來。"""
    head = changed_text if len(changed_text) <= 40 else changed_text[:40] + "…"
    print("\n" + "=" * 60)
    print("修改段落：%s" % head)
    print("=" * 60)

    if not candidates:
        print("沒有找到相似度超過 %.0f%% 的候選條文。" % threshold)
        print("若你認為別的章節應該有對應條文，可以試著 --threshold 35 再跑一次。")
        return

    print("共 %d 筆候選（依相似度排序）：\n" % len(candidates))
    for i, c in enumerate(candidates, 1):
        label = c["article_no"] or ("第%d段" % c["line_number"])
        scope = c.get("scope")
        position = c.get("fragment_position", "")
        # 「多半是公文套語」這句話會叫人跳過這一筆。分數已經很高時這樣講是錯的，
        # 而且錯在整份報告最重要的那一筆上。分數低時它才是有效的排除訊號。
        if position == "句首":
            hint = ""
        elif c["similarity"] >= HIGH_CONFIDENCE:
            hint = "（%s起，但整段相似度高，要細看）" % position
        else:
            hint = "（%s起，多半是公文套語）" % position
        print("[候選%d] 相似度 %.1f%% ｜ %s%s（第%d段）｜ 共同片段 %d 字%s：%s"
              % (i, c["similarity"], (scope + " " if scope else ""), label,
                 c["line_number"], c["fragment_len"], hint, c["common_fragment"]))
        print("  內容：%s" % c["text"])
        if c.get("coverage"):
            print("  這次加的字：%s" % c["coverage"])
        if c.get("context_before"):
            print("  前一段：%s" % c["context_before"][:60])
        if c.get("context_after"):
            print("  後一段：%s" % c["context_after"][:60])
        if c.get("difference"):
            # 「差在哪」直接回答「這是漏改，還是兩個作業的層級本來就不同」
            print("  兩條的差異：%s" % c["difference"])
        if c.get("synonym_evidence"):
            # 一定要說明是哪一組詞讓它配對上的。法遵場合要能回答
            # 「為什麼系統認為這兩條相關」，只給分數不給理由沒有用。
            print("  經同義詞比對：%s" % "、".join(c["synonym_evidence"]))
        print()


def write_changed_text_csv(rows, output_path):
    """「以改動文字搜尋全文」的結果，另存一份，不跟相似度候選混在一起。"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["異動條號", "異動後文字", "這次改動的片段",
                         "關聯章節", "關聯條號", "關聯段次", "關聯條文",
                         "命中的詞", "是否一併修改（人工填寫）"])
        for row in rows:
            writer.writerow(row)
    print("已產生異動文字關聯條文：%s" % output_path)


def write_candidates_csv(rows, output_path):
    """把所有修改段落的候選清單寫成一份 CSV，方便逐筆勾選。"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["修改段落條號", "修改後文字", "候選章節", "候選條號",
                         "候選段次", "候選條文", "相似度", "最長共同片段字數",
                         "片段位置", "最長共同片段", "經同義詞比對",
                         "這次加的字在候選有沒有", "兩條的差異（異動→候選）",
                         "候選前一段", "候選後一段",
                         "是否一併修改（人工填寫）"])
        for row in rows:
            writer.writerow(row)
    print("\n已產生候選清單：%s" % output_path)


def search_keyword(all_paragraphs, phrase, contexts=None, synonyms=None):
    """
    直接找「含有這個詞」的所有條文。給人指定關鍵詞用。

    --------------------------------------------------------------------
    為什麼需要這條路
    --------------------------------------------------------------------
    相似度比對有一個抓不到的區間：條文被大幅改寫、跟原文幾乎沒有共同字時，
    分數會掉到門檻以下，候選清單裡根本不會出現。實測「契約效力之停止，
    以要保人未於約定期日前完成保險費繳付為要件」對上原句只有 40 分，
    在 45 分門檻下抓不到，同義詞表也救不回來。

    試過用「關鍵詞自動重疊」補這一段，實測不可行：中文沒有斷詞套件可用，
    字元 n-gram 會切出「保人」「險費」這種碎片，974 段的內規裡有 319 段
    命中（33%），等於沒有過濾。

    可行的做法是**讓人指定關鍵詞**。法遵知道自己這次改的是「保存期限」，
    直接搜「留存」就好——人選的詞不會有雜訊問題，而且結果完全可預期。
    """
    hits = []
    phrase = (phrase or "").strip()
    if not phrase:
        return hits
    normalized = normalize_terms(phrase, synonyms)[0] if synonyms else phrase

    for idx, paragraph in enumerate(all_paragraphs):
        body = strip_article_no(paragraph)
        body_norm = normalize_terms(body, synonyms)[0] if synonyms else body
        if phrase not in body and normalized not in body_norm:
            continue
        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": idx + 1,
            "article_no": ((context["ref"] if context else "")
                           or extract_article_no(paragraph)),
            "scope": format_scope(context),
            "text": paragraph,
            "matched_by": "原詞" if phrase in body else "同義詞正規化後",
        })
    return hits


def print_keyword_hits(phrase, hits):
    """把關鍵詞搜尋的結果印出來。"""
    print("")
    print("=" * 60)
    print("關鍵詞搜尋：%s" % phrase)
    print("=" * 60)
    if not hits:
        print("全文找不到含這個詞的條文。")
        print("換個說法再試一次，或確認這個詞在內規裡實際怎麼寫。")
        return
    print("共 %d 條含這個詞：" % len(hits))
    print("")
    for hit in hits:
        label = hit["article_no"] or ("第%d段" % hit["line_number"])
        scope = (hit["scope"] + " ") if hit["scope"] else ""
        print("[%s%s（第%d段）] %s" % (scope, label, hit["line_number"],
                                      hit["matched_by"]))
        print("  %s" % hit["text"])
        print("")
    print("提醒：這是「含有這個詞」的完整清單，不是相似度比對。")
    print("      改寫幅度大、字面不像的條文，只有這種搜法找得到。")

def load_changes_from_csv(csv_path, table_format=None):
    """
    從 Step 1 產出的「修正對照表.csv」讀出所有修改段落。

    只取「新增」跟「修改」兩類：這兩類在新版全文裡有對應文字，可以拿去比對。
    「刪除」類在新版全文裡已經不存在，改用它的原文去比，找出「這條刪了，
    但別章還留著同樣的規定沒刪」的情況——這種漏刪一樣是法規風險。
    """
    # 對照表的欄位標題是可以在 對照表格式.json 改的（「原文」可以印成「原條文」），
    # 所以不能照字面去 row["修改後文字"] 取值——各單位改個標題這一步就讀不到了。
    # 對應來源有兩個：呼叫端傳進來的設定（產這份 CSV 時用的那一份，最準），
    # 以及預設設定。都對不上時還有內部鍵本身當備援。
    title_to_key = {}
    for source in (table_format, load_table_format()):
        for column in (source or {}).get("欄位", []):
            if column.get("標題") and column.get("鍵"):
                title_to_key.setdefault(column["標題"], column["鍵"])

    changes = []
    found_text = False
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            values = {}
            for header, value in row.items():
                if header is None:
                    continue
                values[title_to_key.get(header, header)] = value

            change_type = (values.get("修改類型") or "").strip()
            if change_type == "刪除":
                text = (values.get("原文") or "").strip()
                line_no = None
            else:
                text = (values.get("修改後文字") or "").strip()
                raw_line = (values.get("新版段次") or "").strip()
                line_no = int(raw_line) if raw_line.isdigit() else None

            if not text or text.startswith("（無"):
                continue
            found_text = True
            changes.append({
                "article_no": (values.get("條號") or "").strip(),
                "type": change_type,
                "text": text,
                # 舊版原文：用來算出「這次加了哪幾段字」
                "old_text": (values.get("原文") or "").strip(),
                "line_number": line_no,
            })

    # 一筆都讀不到有兩種可能：這次真的沒有異動，或是欄位標題被改過而對不上。
    # 後者最危險——整條流程會在最重要的一步安靜地跳過去，畫面上什麼都不會說。
    if not found_text and not changes:
        print("提醒：從 %s 讀不到任何異動段落。" % os.path.basename(csv_path))
        print("      若這份對照表的欄位標題有改過，請用 --format 指定當初產生它的")
        print("      設定檔（例如 --format scripts/對照表格式.json），否則這一步會空跑。")
    return changes


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 2：跨章節重複條文抓取（模糊字串比對）")
    parser.add_argument("regulation_file",
                        help="【新版】內規全文檔案（.docx / .txt / .md）")
    parser.add_argument("changed_text", nargs="?", default=None,
                        help="你修改後的那段文字；也可以改用 --changed-line 或 --from-csv")
    parser.add_argument("--changed-line", type=int, default=None,
                        help="修改段落在新版全文裡的段次（Step 1 的 CSV「新版段次」欄）")
    parser.add_argument("--from-csv", default=None,
                        help="Step 1 產出的 修正對照表.csv，一次比對所有修改段落")
    parser.add_argument("--keyword", default=None,
                        help="直接列出全文所有含這個詞的條文。"
                             "用在相似度抓不到的地方：條文被大幅改寫、"
                             "跟原文幾乎沒有共同字時，改用人指定的關鍵詞去找")
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD,
                        help="相似度門檻 0~100，預設 %g" % DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=DEFAULT_TOP,
                        help="每個修改段落最多列幾筆候選，預設 %d，設 0 表示全部列出" % DEFAULT_TOP)
    parser.add_argument("--synonyms", default=None,
                        help="同義詞表路徑，預設用 scripts/synonyms.json")
    parser.add_argument("--no-synonyms", action="store_true",
                        help="關閉同義詞正規化，只做純字面比對")
    parser.add_argument("--context", type=int, default=DEFAULT_CONTEXT,
                        help="候選條文附帶前後各幾段，預設 %d；設 0 表示不附"
                             % DEFAULT_CONTEXT)
    parser.add_argument("--format", default=None,
                        help="產生這份對照表時用的版面設定檔；欄位標題改過的話要指定")
    parser.add_argument("--outdir", default="", help="輸出資料夾，預設為目前目錄")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    if synonyms:
        print("已載入同義詞表：%d 組變體" % len(synonyms))
    else:
        print("未使用同義詞表，只做純字面比對。")

    if not HAS_RAPIDFUZZ:
        print("提醒：沒有安裝 rapidfuzz，改用內建 difflib（結果相近，大檔案會慢一些）。")
        print("      要加速請執行：python check_env.py\n")

    print("正在讀取新版內規全文：%s" % args.regulation_file)
    all_paragraphs = read_paragraphs(args.regulation_file)
    contexts = build_hierarchy(all_paragraphs)
    print("全文共 %d 段。" % len(all_paragraphs))

    # 關鍵詞模式：不做相似度比對，直接列出含這個詞的條文
    if args.keyword:
        hits = search_keyword(all_paragraphs, args.keyword,
                              contexts=contexts, synonyms=synonyms)
        print_keyword_hits(args.keyword, hits)
        return hits

    # 決定要比對哪些段落
    if args.from_csv:
        changes = load_changes_from_csv(
            args.from_csv,
            table_format=load_table_format(args.format) if args.format else None)
        if not changes:
            raise SystemExit("錯誤：%s 裡沒有讀到任何修改段落，請確認這是 Step 1 產出的對照表。"
                             % args.from_csv)
        print("從對照表讀到 %d 個修改段落，逐一比對（門檻 %.0f%%）..."
              % (len(changes), args.threshold))
    elif args.changed_line is not None:
        if not (1 <= args.changed_line <= len(all_paragraphs)):
            raise SystemExit("錯誤：--changed-line %d 超出範圍，全文只有 %d 段。"
                             % (args.changed_line, len(all_paragraphs)))
        text = all_paragraphs[args.changed_line - 1]
        changes = [{"article_no": extract_article_no(text), "type": "修改",
                    "text": text, "line_number": args.changed_line}]
    elif args.changed_text:
        changes = [{"article_no": extract_article_no(args.changed_text), "type": "修改",
                    "text": args.changed_text, "line_number": None}]
    else:
        raise SystemExit(
            "錯誤：要指定修改了哪一段。三選一：\n"
            "  直接貼文字   python fuzzy_duplicate_finder.py 新版全文.docx \"第三條 ……\"\n"
            "  指定段次     python fuzzy_duplicate_finder.py 新版全文.docx --changed-line 4\n"
            "  整份跑完     python fuzzy_duplicate_finder.py 新版全文.docx --from-csv 修正對照表.csv")

    csv_rows = []
    total_candidates = 0
    for change in changes:
        candidates = find_duplicates(
            change["text"], all_paragraphs,
            threshold=args.threshold, top=args.top,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms, context_span=args.context,
            changed_old_text=change.get("old_text"))
        total_candidates += len(candidates)
        print_candidates(change["text"], candidates, args.threshold)
        for c in candidates:
            csv_rows.append([
                change["article_no"], change["text"],
                c.get("scope", ""), c["article_no"], c["line_number"], c["text"],
                c["similarity"], c["fragment_len"],
                c.get("fragment_position", ""), c["common_fragment"],
                "、".join(c.get("synonym_evidence", [])),
                c.get("coverage", ""), c.get("difference", ""),
                c.get("context_before", ""), c.get("context_after", ""), "",
            ])

    if csv_rows:
        write_candidates_csv(
            csv_rows, resolve_output(args.outdir, args.prefix, "重複條文候選清單.csv"))

    print("\n" + "-" * 60)
    print("比對完成：%d 個修改段落，共列出 %d 筆候選。" % (len(changes), total_candidates))
    print("提醒：這是 AI 輔助抓取的建議清單，不保證完整覆蓋，最終仍需人工確認。")
    print("-" * 60)

    return csv_rows


if __name__ == "__main__":
    main()
